import { Routes, Route, Link } from 'react-router-dom'
import Inicio from './pages/Inicio'
import TDAH from './pages/TDAH'
import TEA from './pages/TEA'
import Dislexia from './pages/Dislexia'
import Juegos from './pages/Juegos'

function App() {
  return (
    <div>
      <nav className="navbar">
        <h1 className="logo">🧠 Mentes Claras</h1>
        <div className="nav-links">
          <Link to="/">Inicio</Link>
          <Link to="/tdah">TDAH</Link>
          <Link to="/tea">Autismo</Link>
          <Link to="/dislexia">Dislexia</Link>
          <Link to="/juegos">Juegos</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Inicio />} />
        <Route path="/tdah" element={<TDAH />} />
        <Route path="/tea" element={<TEA />} />
        <Route path="/dislexia" element={<Dislexia />} />
        <Route path="/juegos" element={<Juegos />} />
      </Routes>
    </div>
  )
}

export default App
