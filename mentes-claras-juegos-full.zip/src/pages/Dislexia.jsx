function Dislexia() {
  return (
    <div className="container">
      <h2>¿Qué es la Dislexia?</h2>
      <p>Dificultad específica de aprendizaje que afecta la lectura, escritura y ortografía.</p>
    </div>
  )
}
export default Dislexia
