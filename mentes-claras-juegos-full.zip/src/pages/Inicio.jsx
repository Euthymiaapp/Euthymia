function Inicio() {
  return (
    <div className="container">
      <h2>Bienvenidos a Mentes Claras</h2>
      <p>Explora recursos educativos sobre condiciones mentales como el TDAH, TEA y Dislexia.</p>
    </div>
  )
}
export default Inicio
