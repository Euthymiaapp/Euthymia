import { useState } from 'react'

function Juegos() {
  const [counter, setCounter] = useState(0)

  return (
    <div className="container">
      <h2>Juegos Interactivos</h2>
      <h3>Juego rápido de atención</h3>
      <p>Haz clic en el botón tantas veces como puedas:</p>
      <button onClick={() => setCounter(counter + 1)}>Haz clic aquí</button>
      <p>Clicks: <strong>{counter}</strong></p>
    </div>
  )
}

export default Juegos
