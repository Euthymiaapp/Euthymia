function TEA() {
  return (
    <div className="container">
      <h2>¿Qué es el Autismo (TEA)?</h2>
      <p>El Trastorno del Espectro Autista afecta la comunicación y el comportamiento.</p>
    </div>
  )
}
export default TEA
