function TDAH() {
  return (
    <div className="container">
      <h2>¿Qué es el TDAH?</h2>
      <p>Trastorno de atención que dificulta concentrarse, controlar impulsos y mantener la calma.</p>
    </div>
  )
}
export default TDAH
