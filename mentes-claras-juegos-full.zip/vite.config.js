import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  base: '/mentes-claras-juegos-full/',
  plugins: [react()]
})
